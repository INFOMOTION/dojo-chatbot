package de.infomotion.chatbot.dojo.watson;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.ibm.watson.developer_cloud.assistant.v1.model.Context;
import com.ibm.watson.developer_cloud.assistant.v1.model.MessageResponse;

public class WatsonChatbotTest {

	private WatsonChatbot chatbot;

	@Before
	public void setUp() throws Exception {
		chatbot = new WatsonChatbot();
	}

	@Test
	public void testWatsonChatbot() {
		assertNotNull(chatbot);
	}

	@Test
	public void testRespond() {
		Context context = null;
		MessageResponse response = chatbot.respond("Hey", context);
		assertNotNull(response);
		assertEquals(1, response.getOutput().getText().size());
		assertEquals("Um eine Berechnung vorzunehmen benötige ich folgende Informationen von dir: Mit wie viel Sterbegeld möchtest du planen? Und ab wann möchtest du abgesichert sein?", response.getOutput().getText().get(0));

		response = chatbot.respond("Ich möchte ein Sterbegeld von 10000€.", response.getContext());
		assertNotNull(response);
		assertEquals(1, response.getOutput().getText().size());
		assertEquals("Ab wann möchtest du abgesichert sein?", response.getOutput().getText().get(0));

		response = chatbot.respond("Ich möchte ab dem 1.5.2019 abgesichert sein.", response.getContext());
		assertNotNull(response);
		assertEquals(1, response.getOutput().getText().size());
		assertEquals("Zu guter Letzt brauche ich noch dein Geburtsdatum. Du musst zwischen 40 und 99 Jahre alt sein.", response.getOutput().getText().get(0));

		response = chatbot.respond("Ich habe am 24.11.1974 Geburtstag.", response.getContext());
		assertNotNull(response);
		assertEquals(1, response.getOutput().getText().size());
		assertEquals("Ich habe folgende Informationen verstanden: Du möchtest mit €10000 ab dem (today()) abgesichert sein. Dein Geburtstag ist der (\"1977-04-30\").", response.getOutput().getText().get(0));
	}

}
