package de.infomotion.chatbot.dojo.watson;

import com.google.gson.Gson;
import com.ibm.watson.developer_cloud.assistant.v1.Assistant;
import com.ibm.watson.developer_cloud.assistant.v1.model.Context;
import com.ibm.watson.developer_cloud.assistant.v1.model.InputData;
import com.ibm.watson.developer_cloud.assistant.v1.model.MessageOptions;
import com.ibm.watson.developer_cloud.assistant.v1.model.MessageResponse;

public class WatsonChatbot {
	
	private static final String VERSION = "2018-02-16";
	private static final String WORKSPACE_ID = "5366459e-87b5-46b7-80a9-5e29a9749274";
	private static final String USERNAME = "271ff68e-605c-4fc2-be20-002634c8ad7e";
	private static final String PASSWORD = "rlTqv3DOYnHx";
	private static final String ENDPOINT = "https://gateway.watsonplatform.net/assistant/api";
	
	private Assistant service;

	public WatsonChatbot() {
		service = new Assistant(VERSION);
		service.setUsernameAndPassword(USERNAME, PASSWORD);
		service.setEndPoint(ENDPOINT);
	}
	
	public MessageResponse respond(String inputText, Context context) {
		
		InputData input = new InputData.Builder(inputText).build();
		MessageOptions options = new MessageOptions.Builder(WORKSPACE_ID)
					.context(context) // output context from the first message
					.input(input).build();
		MessageResponse response = service.message(options).execute();
		return response;
	}
	
	public MessageResponse respond(String inputText, String contextValue) {
		
		Gson gson = new Gson();
		Context context = gson.fromJson(contextValue, Context.class);
		return respond(inputText, context);
	}

	
}
