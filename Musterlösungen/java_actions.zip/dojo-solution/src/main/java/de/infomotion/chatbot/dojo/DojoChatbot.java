package de.infomotion.chatbot.dojo;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.watson.developer_cloud.assistant.v1.model.Context;
import com.ibm.watson.developer_cloud.assistant.v1.model.MessageResponse;

import de.infomotion.chatbot.dojo.lv1817.ApiConnector;
import de.infomotion.chatbot.dojo.watson.WatsonChatbot;

public class DojoChatbot {

	public static void main(String[] args) throws IOException {
		WatsonChatbot chatbot = new WatsonChatbot();

		ApiConnector api = new ApiConnector();
		JsonParser parser = new JsonParser();

		BufferedReader buffer=new BufferedReader(new InputStreamReader(System.in));

		String input = "";
		Context context = null;
		MessageResponse response;
		do {
			response = chatbot.respond(input, context);			
			context = response.getContext();

			if(response.containsKey("actions")) {
				//				System.out.println(response.get("actions"));
				JsonElement actions = parser.parse(response.get("actions").toString());
				for(JsonElement action : (JsonArray) actions){
//					System.out.println(action);
					if(((JsonObject)action).get("name").getAsString().equals("LV1871")) {
						JsonObject parameters = ((JsonObject)action).get("parameters").getAsJsonObject();
//						System.out.println(parameters);
						context.put("rate", api.calculateRate(
								parameters.get("payment").getAsDouble(),
								parameters.get("birthday").getAsString(),
								parameters.get("startdate").getAsString()));
						response = chatbot.respond(input, context);
						context = response.getContext();
					}
				}
			}

			//			System.out.println(response);
			for(String output : response.getOutput().getText()) {
				System.out.println("Bot:\t" + output);
			}
//			System.out.println("Betrag:\t" + extractContextVariable(response.getContext(), "Sterbegeld"));

			System.out.println();
			System.out.print("User:\t");
			input = buffer.readLine();
		}
		while(input.length() != 0);

	}

	private static Object extractContextVariable(Context context, String variable) {
		if(context.containsKey(variable)) {
			return context.get(variable);
		}
		return null;
	}

}
