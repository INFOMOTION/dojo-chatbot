package de.infomotion.chatbot.dojo.lv1817;

import java.io.IOException;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import jdk.nashorn.internal.parser.JSONParser;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ApiConnector {

	private final static String URL = "https://onlinevertrieb.lv1871.de/lv-online-rest/api/v1/sterbegeld/quote";
	
	private final static String API_KEY_FIELD = "API_KEY";
	private final static String API_KEY = "ee34b3bf-6e85-4a22-97e9-165ab6245e68";
	private OkHttpClient client;

	private JsonParser parser;

	public ApiConnector() {
		client = new OkHttpClient();
		parser = new JsonParser();
	}

	public double calculateRate(double payment, String birthday, String startingDate) {
		
		String body = constructBody(payment, birthday, startingDate);

		Request request = new Request.Builder()
		        .header(API_KEY_FIELD, API_KEY)
		        .url(URL)
		        .post(RequestBody
		                .create(MediaType
		                    .parse("application/json"),
		                        body
		                ))
		        .build();


		try {
			Response response = client.newCall(request).execute();
			JsonObject responseBody = (JsonObject) parser.parse(response.body().string());
			return responseBody.get("beitraege").getAsJsonArray().get(0).getAsJsonObject().get("bruttobetrag").getAsDouble();

		} catch (IOException e) {
			e.printStackTrace();
		}

		return 0;
	}

	private String constructBody(double payment, String birthday, String startingDate) {
		return "{\"versicherungsnehmer\":{\"geburtstag\":\"" + birthday + "T23:00:00.000Z\"},\"versicherungsumfang\":{\"zahlungsweise\":\"Monatlich\",\"ueberschussverwendung\":\"BEITRAGSVERRECHNUNG\",\"versicherungsbeginn\":\"" + startingDate + "T10:00:00.000Z\",\"versicherungssumme\":"+payment+"},\"tarifKuerzel\":[\"SVB\"]} ";
	}

}
