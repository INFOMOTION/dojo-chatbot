package de.infomotion.chatbot.dojo.lv1817;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ApiConnectorTest {

	private ApiConnector api;

	@Before
	public void setUp() throws Exception {
		api = new ApiConnector();;
	}

	@Test
	public void test() {
		double rate = api.calculateRate(10000, "1974-11-24", "2018-04-24");
		Assert.assertEquals(34.45, rate, 0.0001);
		
	}

}
