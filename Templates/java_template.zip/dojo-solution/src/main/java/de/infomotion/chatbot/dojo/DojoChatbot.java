package de.infomotion.chatbot.dojo;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.internal.LinkedTreeMap;
import com.ibm.watson.developer_cloud.assistant.v1.model.Context;
import com.ibm.watson.developer_cloud.assistant.v1.model.MessageResponse;

import de.infomotion.chatbot.dojo.lv1817.ApiConnector;
import de.infomotion.chatbot.dojo.watson.WatsonChatbot;

public class DojoChatbot {

	public static void main(String[] args) throws IOException {
		WatsonChatbot chatbot = new WatsonChatbot();

		ApiConnector api = new ApiConnector();
		JsonParser parser = new JsonParser();

		BufferedReader buffer=new BufferedReader(new InputStreamReader(System.in));

		String input = "";
		Context context = null;
		MessageResponse response;
		do {
			response = chatbot.respond(input, context);			
			context = response.getContext();


			//			System.out.println(response);
			for(String output : response.getOutput().getText()) {
				System.out.println("Bot:\t" + output);
			}

			System.out.println();
			System.out.print("User:\t");
			input = buffer.readLine();
		}
		while(input.length() != 0);

	}

	private static Object extractContextVariable(Context context, String variable) {
		if(context.containsKey(variable)) {
			return context.get(variable);
		}
		return null;
	}

}
