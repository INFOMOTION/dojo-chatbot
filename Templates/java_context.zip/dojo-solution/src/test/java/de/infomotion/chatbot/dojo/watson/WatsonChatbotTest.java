package de.infomotion.chatbot.dojo.watson;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.ibm.watson.developer_cloud.assistant.v1.model.Context;
import com.ibm.watson.developer_cloud.assistant.v1.model.MessageResponse;

public class WatsonChatbotTest {

	private WatsonChatbot chatbot;

	@Before
	public void setUp() throws Exception {
		chatbot = new WatsonChatbot();
	}

	@Test
	public void testWatsonChatbot() {
		assertNotNull(chatbot);
	}

	@Test
	public void testRespond() {
		Context context = null;
		MessageResponse response = chatbot.respond("Hey", context);
		assertNotNull(response);
		assertEquals(0, response.getOutput().getText().size());
//		assertEquals("Hallo, ich bin der Rechner der LV1871. Ich berechne für Dich Deinen Beitrag für die Sterbegeldversicherung.", response.getOutput().getText().get(0));
	}

}
